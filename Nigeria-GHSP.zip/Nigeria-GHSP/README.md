# 335_Data-Dissemination

Part of EPAR's mission includes a "commitment to open access tools and broadly
accessible dissemination." We hope to empower people in developing countries to
make use of the data we create. As part of that mission we have created these
data files as a resource for fellow researchers and decisions makers. 

The data in these files were created using the raw
[LSMS-ISA](http://surveys.worldbank.org/lsms/programs/integrated-surveys-agriculture-ISA)
data collected by the World Bank. 

## Nigeria-GHSP.zip

The data in Nigeria-GHSP.zip were constructed from data collected by the 
[Nigeria National Bureau of Statistics (NBS)](http://www.nigerianstat.gov.ng/)
during the three waves of its [General Household Survey
Panel](http://surveys.worldbank.org/lsms/programs/integrated-surveys-agriculture-ISA/nigeria).
The data was collected in the following years:

	- __Wave 1:__ 2010-11
	- __Wave 2:__ 2012-13
	- __Wave 3:__ 2015-16